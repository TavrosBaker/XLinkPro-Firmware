#include "X360Arduino.h"
#include <USB.h>
#include <esp_mac.h>
#include <device/usbd_pvt.h>
#include <tusb.h>
#include <cstring>
#include <cmath>
extern "C" {
#include "libxsm3/xsm3.h"
}
#include "xinput_descriptors.hpp"

namespace {
// XInput controller button bit masks.
constexpr uint32_t DPAD_UP=0x0001, DPAD_DOWN=0x0002, DPAD_LEFT=0x0004, DPAD_RIGHT=0x0008;
constexpr uint32_t START=0x0010, BACK=0x0020, LS=0x0040, RS=0x0080;
constexpr uint32_t LB=0x0100, RB=0x0200, GUIDE=0x0400;
constexpr uint32_t BTN_A=0x1000, BTN_B=0x2000, BTN_X=0x4000, BTN_Y=0x8000;
struct ControllerState { uint32_t buttons; float lx,ly,rx,ry,lt,rt; };
uint8_t input_ep=0;
uint8_t out_buffer[32]{};
uint8_t report_buffer[20]{};
uint8_t auth_buffer[48]{};
uint8_t identity[29]{};
uint16_t response_length=0, response_state=1;
volatile uint8_t auth_phase=0;
bool initialized=false;

void reset(uint8_t) { input_ep=0; auth_phase=0; initialized=false; response_length=0; response_state=1; xsm3_initialise_state(); }
void driver_init() { reset(0); }
uint16_t driver_open(uint8_t port, const tusb_desc_interface_t *iface, uint16_t maxlen) {
  if (!iface || iface->bInterfaceClass!=0xff) return 0;
  const auto *begin=reinterpret_cast<const uint8_t*>(iface);
  size_t len=iface->bLength;
  while (len<maxlen) {
    if (maxlen-len<2 || begin[len]<2 || begin[len]>maxlen-len) return 0;
    if (begin[len+1]==TUSB_DESC_INTERFACE) break;
    if (begin[len+1]==TUSB_DESC_ENDPOINT && iface->bInterfaceNumber==0) {
      const auto *ep=reinterpret_cast<const tusb_desc_endpoint_t*>(begin+len);
      if (!usbd_edpt_open(port,ep)) return 0;
      if (ep->bEndpointAddress & 0x80) input_ep=ep->bEndpointAddress;
    }
    len+=begin[len];
  }
  if (iface->bInterfaceNumber==0) usbd_edpt_xfer(port,0x02,out_buffer,sizeof(out_buffer),false);
  return len;
}
bool driver_control(uint8_t,uint8_t,const tusb_control_request_t*) { return false; }
bool driver_transfer(uint8_t port,uint8_t ep,xfer_result_t,uint32_t) {
  if (ep==0x02) usbd_edpt_xfer(port,ep,out_buffer,sizeof(out_buffer),false);
  return true;
}
// TinyUSB's private app-driver hook lets us add XInput's vendor class.
const usbd_class_driver_t class_driver={"X360Arduino XInput",driver_init,nullptr,reset,driver_open,driver_control,driver_transfer,nullptr,nullptr};

void prepareIdentity() {
  memcpy(identity,xsm3_id_data_ms_controller,sizeof(identity));
  uint8_t mac[6]{}; esp_read_mac(mac,ESP_MAC_WIFI_STA);
  const char *digits="0123456789ABCDEF";
  for (int i=0;i<6;i++) { identity[5+2*i]=digits[mac[i]>>4]; identity[6+2*i]=digits[mac[i]&15]; }
  uint8_t check=0; for (unsigned i=5;i<28;i++) check^=identity[i]; identity[28]=check;
}
bool validTarget(unsigned recipient,uint16_t index) { return recipient==0 || (recipient==1 && (index==3 || index==0x0301)); }
bool xb_valid_xsm3_packet(const uint8_t *p,size_t size) {
  if (!p || (size!=34 && size!=22) || size_t(p[4])+6!=size) return false;
  uint8_t checksum=0; for (size_t i=5;i<size-1;i++) checksum^=p[i]; return checksum==p[size-1];
}

uint8_t device_desc[] = {18,TUSB_DESC_DEVICE,0x00,0x02,0xff,0xff,0xff,64,0x5e,0x04,0x8e,0x02,0x14,0x01,1,2,3,1};
const char *strings[] = {"\x09\x04","Microsoft","Controller","XBridge360-ESP32S3","Xbox Security Method 3, Version 1.00"};
uint16_t string_desc[64];
}

// These callbacks are weak in Arduino-ESP32's TinyUSB glue and replace its
// default device/configuration/string descriptors for this sketch.
extern "C" uint8_t const *tud_descriptor_device_cb(void) { return device_desc; }
extern "C" uint8_t const *tud_descriptor_configuration_cb(uint8_t) { return xbox_configuration; }
extern "C" uint16_t const *tud_descriptor_string_cb(uint8_t index,uint16_t) {
  if (index>=5) return nullptr;
  uint8_t n=0;
  if (index==0) { string_desc[1]=0x0409; n=1; }
  else { const char *s=strings[index]; while (s[n] && n<62) { string_desc[1+n]=(uint8_t)s[n]; n++; } }
  string_desc[0]=(TUSB_DESC_STRING<<8)|(2*n+2);
  return string_desc;
}
extern "C" const usbd_class_driver_t *usbd_app_driver_get_cb(uint8_t *count) { *count=1; return &class_driver; }

// Arduino-ESP32 already defines tud_vendor_control_xfer_cb (non-weak), and
// forwards unhandled vendor requests to this weak application callback.
extern "C" bool tinyusb_vendor_control_request_cb(uint8_t port,uint8_t stage,const tusb_control_request_t *req) {
  if (!req || req->bmRequestType_bit.type!=TUSB_REQ_TYPE_VENDOR || !validTarget(req->bmRequestType_bit.recipient,req->wIndex)) return false;
  if (req->bmRequestType_bit.direction==TUSB_DIR_IN) {
    if (stage==CONTROL_STAGE_SETUP) {
      switch(req->bRequest) {
        case 0x81: xsm3_initialise_state(); xsm3_set_identification_data(identity); initialized=false; response_state=1; response_length=0; auth_phase=1; return tud_control_xfer(port,req,identity,sizeof(identity));
        case 0x83: if (!response_length) return false; memcpy(auth_buffer,xsm3_challenge_response,response_length); return tud_control_xfer(port,req,auth_buffer,response_length);
        case 0x84: return tud_control_status(port,req);
        case 0x86: return tud_control_xfer(port,req,&response_state,sizeof(response_state));
        default: return false;
      }
    }
    if (stage==CONTROL_STAGE_ACK && req->bRequest==0x83 && auth_phase==3) auth_phase=4;
    return true;
  }
  const size_t expected=req->bRequest==0x82?34:req->bRequest==0x87?22:0;
  if (!expected || req->wLength!=expected || auth_phase==0) return false;
  if (stage==CONTROL_STAGE_SETUP) return tud_control_xfer(port,req,auth_buffer,expected);
  if (stage==CONTROL_STAGE_DATA) {
    response_length=0; response_state=1;
    if (!xb_valid_xsm3_packet(auth_buffer,expected) || (req->bRequest==0x87 && !initialized)) { auth_phase=5; return false; }
    if (req->bRequest==0x82) xsm3_do_challenge_init(auth_buffer); else xsm3_do_challenge_verify(auth_buffer);
    if (xsm3_last_error) { auth_phase=5; initialized=false; return false; }
    initialized=true; response_length=req->bRequest==0x82?46:22; response_state=2; auth_phase=req->bRequest==0x82?2:3;
  }
  return true;
}
X360ArduinoClass X360Arduino;
bool X360ArduinoClass::begin() {
  if (started_) return true;
  prepareIdentity();
  // USB mode must be set to USB-OTG (TinyUSB) in Arduino IDE Tools.
  started_=USB.begin();
  return started_;
}
bool X360ArduinoClass::ready() const { return started_ && tud_mounted() && input_ep!=0; }
bool X360ArduinoClass::send() {
  if (!ready() || (buttons_&~0xf7ffU)) return false;
  float axes[]={lx_,-ly_,rx_,-ry_};
  for (float v:axes) if (!isfinite(v)||v < -1||v>1) return false;
  if (!isfinite(lt_)||!isfinite(rt_)||lt_<0||lt_>1||rt_<0||rt_>1) return false;
  if (!usbd_edpt_claim(0,input_ep)) return false;
  memset(report_buffer,0,sizeof(report_buffer)); report_buffer[1]=20;
  report_buffer[2]=buttons_&255; report_buffer[3]=(buttons_>>8)&255;
  report_buffer[4]=(uint8_t)lroundf(lt_*255); report_buffer[5]=(uint8_t)lroundf(rt_*255);
  for(int i=0;i<4;i++){ float v=axes[i]; int16_t a=(int16_t)lroundf(v*(v<0?32768:32767)); report_buffer[6+2*i]=(uint16_t)a&255; report_buffer[7+2*i]=((uint16_t)a>>8)&255; }
  if (!usbd_edpt_xfer(0,input_ep,report_buffer,sizeof(report_buffer),false)) { usbd_edpt_release(0,input_ep); return false; }
  return true;
}
bool X360ArduinoClass::setState(uint32_t buttons,float lx,float ly,float rx,float ry,float lt,float rt) {
  if ((buttons & ~0xf7ffU) != 0 ||
      !isfinite(lx) || !isfinite(ly) || !isfinite(rx) || !isfinite(ry) ||
      !isfinite(lt) || !isfinite(rt) ||
      lx < -1 || lx > 1 || ly < -1 || ly > 1 ||
      rx < -1 || rx > 1 || ry < -1 || ry > 1 ||
      lt < 0 || lt > 1 || rt < 0 || rt > 1) return false;
  buttons_=buttons;
  lx_=lx;ly_=ly;rx_=rx;ry_=ry;lt_=lt;rt_=rt;
  return send();
}
bool X360ArduinoClass::setButton(uint32_t mask,bool down){ if(down)buttons_|=mask;else buttons_&=~mask;return send(); }
bool X360ArduinoClass::button(X360Button which, bool down) {
  switch (which) {
    case X360Button::DpadUp: return dpadUp(down);
    case X360Button::DpadDown: return dpadDown(down);
    case X360Button::DpadLeft: return dpadLeft(down);
    case X360Button::DpadRight: return dpadRight(down);
    case X360Button::Start: return start(down);
    case X360Button::Back: return back(down);
    case X360Button::LeftStickClick: return leftStickClick(down);
    case X360Button::RightStickClick: return rightStickClick(down);
    case X360Button::LeftBumper: return leftBumper(down);
    case X360Button::RightBumper: return rightBumper(down);
    case X360Button::Guide: return guide(down);
    case X360Button::A: return a(down);
    case X360Button::B: return b(down);
    case X360Button::X: return x(down);
    case X360Button::Y: return y(down);
  }
  return false;
}
bool X360ArduinoClass::dpadUp(bool v){return setButton(DPAD_UP,v);} bool X360ArduinoClass::dpadDown(bool v){return setButton(DPAD_DOWN,v);} bool X360ArduinoClass::dpadLeft(bool v){return setButton(DPAD_LEFT,v);} bool X360ArduinoClass::dpadRight(bool v){return setButton(DPAD_RIGHT,v);}
bool X360ArduinoClass::start(bool v){return setButton(START,v);} bool X360ArduinoClass::back(bool v){return setButton(BACK,v);} bool X360ArduinoClass::leftStickClick(bool v){return setButton(LS,v);} bool X360ArduinoClass::rightStickClick(bool v){return setButton(RS,v);} bool X360ArduinoClass::leftBumper(bool v){return setButton(LB,v);} bool X360ArduinoClass::rightBumper(bool v){return setButton(RB,v);} bool X360ArduinoClass::guide(bool v){return setButton(GUIDE,v);} bool X360ArduinoClass::a(bool v){return setButton(BTN_A,v);} bool X360ArduinoClass::b(bool v){return setButton(BTN_B,v);} bool X360ArduinoClass::x(bool v){return setButton(BTN_X,v);} bool X360ArduinoClass::y(bool v){return setButton(BTN_Y,v);}
bool X360ArduinoClass::leftTrigger(float v){if(!isfinite(v)||v<0||v>1)return false;lt_=v;return send();} bool X360ArduinoClass::rightTrigger(float v){if(!isfinite(v)||v<0||v>1)return false;rt_=v;return send();}
bool X360ArduinoClass::leftStick(float x,float y){if(!isfinite(x)||!isfinite(y)||x < -1||x>1||y < -1||y>1)return false;lx_=x;ly_=y;return send();} bool X360ArduinoClass::rightStick(float x,float y){if(!isfinite(x)||!isfinite(y)||x < -1||x>1||y < -1||y>1)return false;rx_=x;ry_=y;return send();}
bool X360ArduinoClass::releaseAll(){buttons_=0;lx_=ly_=rx_=ry_=lt_=rt_=0;return send();}
const char *X360ArduinoClass::authenticationStatus() const { static const char *s[]={"Not requested", "Identification sent", "Init response ready", "Verify response ready", "Verify transferred; console acceptance unconfirmed", "Challenge rejected"}; uint8_t p=auth_phase; return p<6?s[p]:"Unknown"; }
