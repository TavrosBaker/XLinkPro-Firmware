#include <X360Arduino.h>

// Demonstrates button taps and analog trigger values.
// This is a demo sequence, not a game-specific macro.
void setup() {
  Serial.begin(115200);
  delay(800);
  X360Arduino.begin();
}

void loop() {
  X360Arduino.button(X360Button::A, true);
  delay(150);
  X360Arduino.button(X360Button::A, false);
  delay(350);

  X360Arduino.leftTrigger(1.0f);  // full press
  delay(200);
  X360Arduino.leftTrigger(0.0f);  // release
  delay(1000);
}
