# X360Arduino v1.0.0

**An Arduino IDE library for using an ESP32-S3 as an Xbox 360-style USB controller.** It provides direct functions for every standard Xbox 360 controller button, both triggers, and both analog sticks. USB descriptors, controller reports, and the bundled XSM3 challenge-response implementation are included in the library.

> **Compatibility note:** This library is based on the XBridge360 Arduino port that was successfully installed and tested to compile/upload in the author's setup. ESP32 Arduino/TinyUSB internals vary between core versions and boards. A successful upload does not, by itself, prove Xbox enumeration/authentication. Use the known-working ESP32-S3 board/core/USB settings from your existing setup when possible.

## Quick start

1. In Arduino IDE, select **Sketch → Include Library → Add .ZIP Library…** and choose `X360Arduino.zip`.
2. Restart Arduino IDE if the library does not appear immediately.
3. Select your ESP32-S3 board and its native USB data port.
4. In **Tools**, select **USB Mode → USB-OTG (TinyUSB)** if that option is available for your board/core.
5. Open **File → Examples → X360Arduino → DpadRightEvery2Seconds**.
6. Verify, upload, and test with the ESP32-S3 connected to the Xbox's USB port.

Do not install it over the old `XBridge360Arduino` folder. It has a different library name and header. Keep the old library until you've confirmed the new one works, then remove the old folder from `Documents/Arduino/libraries/XBridge360Arduino` if desired.

## Basic pattern

```cpp
#include <X360Arduino.h>

void setup() {
  X360Arduino.begin();
}

void loop() {
  X360Arduino.a(true);   // press and hold A
  delay(150);
  X360Arduino.a(false);  // release A
  delay(1000);
}
```

Button calls update the stored controller state and try to send a report immediately. The return value is `true` if the report was queued successfully, not a guarantee the game acted on it. `send()` retries sending the current stored state.

## Full API reference

### Startup and status

| Function | Meaning |
|---|---|
| `X360Arduino.begin()` | Starts USB device support. Call once in `setup()`. |
| `X360Arduino.ready()` | `true` when TinyUSB reports mounted and the controller input endpoint has opened. |
| `X360Arduino.connected()` | Alias for `ready()`. It reports USB readiness, not necessarily Xbox authentication acceptance. |
| `X360Arduino.send()` | Sends the currently stored state again. |
| `X360Arduino.releaseAll()` | Releases all buttons, releases both triggers, and centers both sticks. |
| `X360Arduino.authenticationStatus()` | Returns a short string describing the internal XSM3 challenge phase. This is diagnostic only, not proof of console acceptance. |

### Buttons

Every button function accepts `true` for pressed/held and `false` for released. You must release a button when you want a tap rather than a hold.

| Function | Xbox 360 control |
|---|---|
| `dpadUp(bool)` | D-pad up |
| `dpadDown(bool)` | D-pad down |
| `dpadLeft(bool)` | D-pad left |
| `dpadRight(bool)` | D-pad right |
| `a(bool)` | A |
| `b(bool)` | B |
| `x(bool)` | X |
| `y(bool)` | Y |
| `start(bool)` | Start / Menu |
| `back(bool)` | Back / View |
| `guide(bool)` | Guide / Xbox button |
| `leftBumper(bool)` | Left bumper / LB |
| `rightBumper(bool)` | Right bumper / RB |
| `leftStickClick(bool)` | Left stick click / L3 |
| `rightStickClick(bool)` | Right stick click / R3 |

Generic equivalent:

```cpp
X360Arduino.button(X360Button::A, true);
X360Arduino.button(X360Button::A, false);
X360Arduino.button(X360Button::DpadRight, true);
X360Arduino.button(X360Button::DpadRight, false);
```

Available `X360Button` values: `DpadUp`, `DpadDown`, `DpadLeft`, `DpadRight`, `Start`, `Back`, `LeftStickClick`, `RightStickClick`, `LeftBumper`, `RightBumper`, `Guide`, `A`, `B`, `X`, `Y`.

You can hold multiple buttons at once; pressing one button does not automatically release other buttons. Call `releaseAll()` to clear the full state.

### Triggers

```cpp
X360Arduino.leftTrigger(0.0f);  // released
X360Arduino.leftTrigger(0.5f);  // half pressed
X360Arduino.leftTrigger(1.0f);  // fully pressed

X360Arduino.rightTrigger(1.0f);
X360Arduino.rightTrigger(0.0f);
```

Valid values are from `0.0f` through `1.0f`. Values outside that range are rejected.

### Analog sticks

Each axis accepts values from `-1.0f` through `+1.0f`.

- X axis: `-1.0` left, `0.0` center, `+1.0` right.
- Y axis: `-1.0` down, `0.0` center, `+1.0` up.

```cpp
X360Arduino.leftStick(0.0f, 0.0f);    // center left stick
X360Arduino.leftStick(-1.0f, 0.0f);   // full left
X360Arduino.leftStick(0.0f, 1.0f);    // full up
X360Arduino.rightStick(0.5f, -0.25f); // right stick: right and slightly down
X360Arduino.rightStick(0.0f, 0.0f);   // center right stick
```

The library converts the floating-point axes into signed 16-bit controller values. Out-of-range or non-finite values are rejected.

## Timed actions without blocking the sketch

Use `millis()` to schedule taps so your sketch can do other work. Example: tap right for 150 ms every 2 seconds.

```cpp
#include <X360Arduino.h>
const uint32_t PRESS_MS = 150;
const uint32_t INTERVAL_MS = 2000;
uint32_t lastTap = 0, pressedAt = 0;
bool pressed = false;

void setup() { X360Arduino.begin(); }

void loop() {
  uint32_t now = millis();
  if (!pressed && now - lastTap >= INTERVAL_MS) {
    X360Arduino.dpadRight(true);
    pressed = true;
    pressedAt = now;
    lastTap = now;
  }
  if (pressed && now - pressedAt >= PRESS_MS) {
    X360Arduino.dpadRight(false);
    pressed = false;
  }
  delay(1);
}
```

## Examples included

- **DpadRightEvery2Seconds** — the simple repeating D-pad test.
- **ButtonAndTriggerDemo** — taps A and tests the left trigger.
- **AnalogSticksDemo** — moves the left stick in four directions and centers it.

## Troubleshooting

- **`X360Arduino.h: No such file`** — confirm the ZIP installed and the folder is `Documents/Arduino/libraries/X360Arduino/`; restart the IDE.
- **`USB startup failed` / `ready()` stays false** — check the selected ESP32-S3 board, native USB data connector, USB-OTG/TinyUSB setting, and the Arduino-ESP32 core version. Some boards have separate USB-to-serial and native USB connectors.
- **Build errors mentioning `device/usbd_pvt.h`, TinyUSB hooks, or descriptors** — those are internal, version-sensitive Arduino-ESP32 interfaces. Use the same board package/core version that worked with your prior XBridge360Arduino install.
- **Uploads, but Xbox does not respond** — upload success is not proof that the Xbox accepted the device. Check `ready()` and `authenticationStatus()`, use the native USB port, and confirm the console sees the device. The status string cannot conclusively confirm Xbox acceptance.
- **Button remains held** — every `... (true)` press needs a corresponding `... (false)` release, unless you intentionally want to hold it. `releaseAll()` clears everything.
- **A function returns `false`** — this usually means the current state was not successfully queued to USB. The state is retained for most valid control calls; call `send()` again after `ready()` becomes true.

## Notes / limitations

- Intended for ESP32-S3 with native USB device support; not all ESP32 chips have USB-OTG hardware.
- Does not include Wi-Fi control, a web dashboard, Bluetooth, physical input reading, macros editor, or game-specific behavior. Those can be implemented in your Arduino sketch.
- This library represents a standard controller state; it cannot guarantee every game uses every button identically.
- USB endpoint handling and authentication hooks depend on Arduino-ESP32/TinyUSB implementation details.

## Source and licensing

This package includes XSM3 / ExCrypt source files and license notices under `src/libxsm3/`. The XInput descriptor file preserves its upstream attribution and MIT SPDX notice in `src/xinput_descriptors.hpp`. Review the included license files before redistributing modified packages.
